﻿import pygame
from Ken import *
from Ryu import *
from class_PersoGlobal import *
import time

pygame.font.init()

class Game:

    def __init__(self):

        #defini la police
        self.font= pygame.font.Font('Minecraft.ttf',30)
        self.font_chrono = pygame.font.Font('Minecraft.ttf',40)

        #defini txt
        self.pseudo2 = self.font.render('Ken', True,(0,0,255))
        self.pseudo1 = self.font.render("Ryu ",True,(0,0,255))

        self.temps = 46
        self.stop = False


        self.ryu = Ryu(self)
        self.ken = Ken(self)
        self.all_ken = pygame.sprite.Group()
        self.all_ken.add(self.ken)

        self.all_ryu = pygame.sprite.Group()
        self.all_ryu.add(self.ryu)



    def affichage(self,screen):
          screen.blit(self.txt_rebours,(460,20))
          screen.blit(self.pseudo2,(10,40))
          screen.blit(self.pseudo1,(900,40))
          self.ken.barre_de_vie_ken(screen)
          self.ryu.barre_de_vie_ryu(screen)



    def check_collision(self,sprite, group):

        return pygame.sprite.spritecollide(sprite, group, False, pygame.sprite.collide_mask)


    def temps_réel(self,begin):

        accueil=0

        now = time.time()


        clock = now - begin
        rebours = (self.temps - clock)
        rebours = str(rebours)
        i = 0
        self.rebours = ""
        if self.stop == False:
            while rebours[i] != '.':
                 self.rebours +=rebours[i]
                 i = i + 1
            if len(self.rebours) == 1:
                valeur = self.rebours
                self.rebours = "0"+valeur


##            if self.rebours != "00":
##                musique = pygame.mixer.music.load("Combat.ogg")
##                musique = pygame.mixer.music.set_volume(0.1)
##                pygame.mixer.music.play(1)

            if self.rebours <= "00":
                self.stop=True

                if self.stop==True:
                    pygame.display.set_caption("FIN")
                    finish2=pygame.image.load("asserts/Egalite.png")
                    screen2.blit(finish2, (0,0))
                    pygame.display.flip()
                    pygame.mixer.music.stop()
                    time.sleep(5)
                    pygame.quit()

            if self.ryu.vie <= 0 or self.ken.vie <= 0:
                pygame.display.set_caption("FIN")
                finish2=pygame.image.load("asserts/Fin.png")
                screen2.blit(finish2, (0,0))
                pygame.display.flip()
                KO2= pygame.mixer.music.load("KO.ogg")
                KO2 = pygame.mixer.music.set_volume(0.1)
                pygame.mixer.music.play()
                time.sleep(5)
                pygame.quit()


# Tentative de création d'un menu d'accueil

##                if accueil == 0:
##                    pygame.display.set_caption("Street Fighter ")
##                background = pygame.image.load("asserts/background.jpg")
##                screen = pygame.display.set_mode((960,600))
##                pygame.display.flip()
##                musique = pygame.mixer.music.load("Combat.ogg")
##                musique = pygame.mixer.music.set_volume(0.1)
##                pygame.mixer.music.stop()
##                accueil=1
##
##                if accueil == 1:
##                    jeu_en_cours = True
##
##                    while jeu_en_cours :
##
##                        for event in pygame.event.get():
##                            if event.type == pygame.QUIT:
##                                 jeu_en_cours = False
##
##                            pygame.mixer.music.stop()
##                            pygame.display.set_caption("FIN")
##                            self.font.render("Egalité ! ",True,(0,0,255))
##                            pygame.display.flip()
##                            musique2 = pygame.mixer.music.load("Egalité.ogg")
##                            musique2 = pygame.mixer.music.set_volume(0.1)
##                            pygame.mixer.music.play()


            self.txt_rebours = self.font_chrono.render(self.rebours,True,(0,0,255))