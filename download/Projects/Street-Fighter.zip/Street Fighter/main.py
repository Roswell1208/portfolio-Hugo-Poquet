﻿import pygame
from game import *
import time

pygame.init()
pygame.font.init()


pygame.display.set_caption("Street Fighter ")
background = pygame.image.load("asserts/background.jpg")
screen = pygame.display.set_mode((960,600))

musique = pygame.mixer.music.load("Combat.ogg")
musique = pygame.mixer.music.set_volume(0.1)
pygame.mixer.music.play()

running = True
pressed = {}

game = Game()
begin = time.time()



while running :

  #afficher le fond ecran
  screen.blit(background, (0,0))


  #gestion du temps
  game.temps_réel(begin)

  #afficher les données
  game.affichage(screen)

  screen.blit(game.ryu.image,game.ryu.rect)
  screen.blit(game.ken.image,game.ken.rect)

  #appliquer l'ensemble des images

  pygame.display.flip()

  if game.ken.saut == True:
    game.ken.gravite_ken()
  if game.ryu.saut == True:
    game.ryu.gravite_ryu()

  if game.ken.validation == True:
    game.ken.mouvement_saut()
  if game.ryu.validation:
    game.ryu.mouvement_saut()




  if pressed.get(pygame.K_d) == True and game.ryu.rect.x <=595 : #and pressed.get(pygame.K_LEFT) == False and pressed.get(pygame.K_UP) == False and pressed.get(pygame.K_DOWN) == False
    if not game.check_collision(game.ryu,game.all_ken) or game.ryu.horientation == "Left":
        game.ryu.mouvement_droit()

  if pressed.get(pygame.K_a) == True and game.ryu.rect.x >=5:
    if not game.check_collision(game.ryu,game.all_ken) or game.ryu.horientation == "Right":
        game.ryu.mouvement_gauche()





  if pressed.get(pygame.K_LEFT) == True and game.ken.rect.x >=5:
    if not game.check_collision(game.ken,game.all_ryu) or game.ken.horientation == "Right":
        game.ken.mouvement_gauche()

  if pressed.get(pygame.K_RIGHT) == True and game.ken.rect.x <=595:
    if not game.check_collision(game.ken,game.all_ryu) or game.ken.horientation == "Left":
        game.ken.mouvement_droit()


  for event in pygame.event.get():

        if event.type == pygame.QUIT:
            end = time.time()
            running = False
            pygame.quit()


        elif event.type == pygame.KEYDOWN:
            pressed[event.key] = True


            if event.key == pygame.K_UP and game.ken.saut == False:
                game.ken.validation = True
            if event.key == pygame.K_w and game.ryu.saut == False:
                game.ryu.validation = True

            if event.key == pygame.K_SPACE:



                if game.ryu.horientation == "Right":




                    image_Ryu_att = "asserts/Ryu kick.png"
                    R_att = pygame.image.load(image_Ryu_att)
                    R_att = pygame.transform.scale(R_att,(350,350))
                    game.ryu.image= R_att
                    if game.check_collision (game.ryu,game.all_ken):
                        game.ken.damage()

                if game.ryu.horientation == "Left":




                    image_Ryu_att = ("asserts/Ryu kick_mirror.png")
                    R_att = pygame.image.load(image_Ryu_att)
                    R_att = pygame.transform.scale(R_att,(350,350))
                    game.ryu.image= R_att
                    if game.check_collision (game.ryu,game.all_ken):
                        game.ken.damage()







            if event.key == pygame.K_RETURN:

                if game.ken.horientation == "Left":





                    K_att = pygame.image.load("asserts/Ken kick_mirror.png")
                    K_att = pygame.transform.scale(K_att,(300,300))
                    game.ken.image= K_att
                    if game.check_collision (game.ken,game.all_ryu):
                        game.ryu.damage()

                if game.ken.horientation == "Right":





                    image_Ken_att = pygame.image.load("asserts/Ken kick.png")
                    K_att =  pygame.transform.scale(image_Ken_att,(300,300))
                    game.ken.image= K_att
                    if game.check_collision (game.ken,game.all_ryu):
                        game.ryu.damage()



        elif event.type == pygame.KEYUP:
            pressed[event.key] = False

