﻿class Perso:

    def __init__(self,game):
        self.variable = 0
        self.game = game


    def mouvement_saut(self):
        self.saut = True
        if self.rect.y > 50:
            self.rect.y -= 10
        else:
            self.validation = False







