﻿from PIL import Image
from PIL import ImageOps

im = Image.open("asserts/Ken kick.PNG")

im = ImageOps.mirror(im)

im.save("asserts/Ken kick_mirror.png")
im.show()