﻿import pygame
from class_PersoGlobal import *

screen2 = pygame.display.set_mode((960,600))

class Ryu(pygame.sprite.Sprite,Perso):

    def __init__(self,game):
        super().__init__()
        self.game = game
        self.vie=100
        self.degats=20
        self.vitesse=5
        self.image = pygame.image.load("asserts/Ryu.png")
        self.image2 = pygame.image.load("asserts/Ryu_mirror.png")
        self.image = pygame.transform.scale(self.image, (300, 300))
        self.image2 = pygame.transform.scale(self.image2, (300, 300))
        self.image3 = self.image
        self.rect=self.image.get_rect()
        self.rect.x=0
        self.rect.y=300
        self.saut = True
        self.horientation = "Right"
        self.validation = False

    def damage(self):
    #Infliger les degats

        if self.vie -self.degats >= 0:
            self.vie -= self.degats

        if self.vie <=0:
            pygame.display.set_caption("FIN")
            finish=pygame.image.load("asserts/Fin.png")
            screen2.blit(finish, (0,0))
##            pygame.display.flip()
            K0=pygame.mixer.music.load("KO.ogg")
            K0=pygame.mixer.music.set_volume(0.1)
            pygame.mixer.music.play()
##            pygame.mixer.music.stop()

    def mouvement_droit(self):
        self.image = self.image3
        self.rect.x += self.vitesse
        self.horientation = "Right"

    def mouvement_gauche(self):
        self.image = self.image2
        self.rect.x -= self.vitesse
        self.horientation = "Left"


    def gravite_ryu(self):

        if self.rect.y != 300 and not self.game.check_collision(self,self.game.all_ken):
            self.rect.y += 4
            self.saut = True

        elif self.game.check_collision(self,self.game.all_ken) and self.horientation == "Right"and self.rect.y != 300:
            self.rect.y += 4
            self.rect.x -=10
            self.saut = True

        elif self.game.check_collision(self,self.game.all_ken) and self.horientation == "Left" and self.rect.y != 300:
            self.rect.y += 4
            self.rect.x +=10
            self.saut = True

        else:
            self.saut = False

    def barre_de_vie_ryu(self,screen):
        jaune = (255,215,0)
        noir = (0,0,0)
        rouge = (255,0,0)

        bar_position =(10,20,self.vie*4,20)
        bar_position_max = (10,20,100*4,20)

##        pygame.draw.rect(screen, noir ,(self.rect.x+50,self.rect.y,200,300),3)
        pygame.draw.rect(screen, noir, bar_position_max,3)
        pygame.draw.rect(screen, jaune, bar_position)
##        pygame.draw.rect(screen,rouge,(self.rect.x+70,self.rect.y+20,150,275),3)




