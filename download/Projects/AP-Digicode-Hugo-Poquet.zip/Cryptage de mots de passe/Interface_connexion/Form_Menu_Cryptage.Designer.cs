﻿namespace Interface_connexion
{
    partial class Form_Menu_Cryptage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Menu_Cryptage));
            this.btn_crypter_batiment = new System.Windows.Forms.Button();
            this.btn_crypter_salle_info = new System.Windows.Forms.Button();
            this.btn_quitter = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_crypter_batiment
            // 
            this.btn_crypter_batiment.BackColor = System.Drawing.Color.White;
            this.btn_crypter_batiment.ForeColor = System.Drawing.Color.Black;
            this.btn_crypter_batiment.Location = new System.Drawing.Point(126, 195);
            this.btn_crypter_batiment.Name = "btn_crypter_batiment";
            this.btn_crypter_batiment.Size = new System.Drawing.Size(212, 106);
            this.btn_crypter_batiment.TabIndex = 0;
            this.btn_crypter_batiment.Text = "Crypter un mot de passe pour l\'accès au bâtiment";
            this.btn_crypter_batiment.UseVisualStyleBackColor = false;
            this.btn_crypter_batiment.Click += new System.EventHandler(this.btn_crypter_batiment_Click);
            // 
            // btn_crypter_salle_info
            // 
            this.btn_crypter_salle_info.BackColor = System.Drawing.Color.White;
            this.btn_crypter_salle_info.Location = new System.Drawing.Point(479, 195);
            this.btn_crypter_salle_info.Name = "btn_crypter_salle_info";
            this.btn_crypter_salle_info.Size = new System.Drawing.Size(212, 106);
            this.btn_crypter_salle_info.TabIndex = 1;
            this.btn_crypter_salle_info.Text = "Crypter un mot de passe pour la salle informatique";
            this.btn_crypter_salle_info.UseVisualStyleBackColor = false;
            this.btn_crypter_salle_info.Click += new System.EventHandler(this.btn_crypter_salle_info_Click);
            // 
            // btn_quitter
            // 
            this.btn_quitter.BackColor = System.Drawing.Color.White;
            this.btn_quitter.Location = new System.Drawing.Point(321, 356);
            this.btn_quitter.Name = "btn_quitter";
            this.btn_quitter.Size = new System.Drawing.Size(172, 82);
            this.btn_quitter.TabIndex = 2;
            this.btn_quitter.Text = "Quitter";
            this.btn_quitter.UseVisualStyleBackColor = false;
            this.btn_quitter.Click += new System.EventHandler(this.btn_quitter_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(306, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 28);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choisissez une section :";
            this.label1.UseWaitCursor = true;
            // 
            // Form_Menu_Cryptage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_quitter);
            this.Controls.Add(this.btn_crypter_salle_info);
            this.Controls.Add(this.btn_crypter_batiment);
            this.Name = "Form_Menu_Cryptage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Cryptage";
            this.Load += new System.EventHandler(this.Form_Menu_Cryptage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btn_crypter_batiment;
        private Button btn_crypter_salle_info;
        private Button btn_quitter;
        private Label label1;
    }
}