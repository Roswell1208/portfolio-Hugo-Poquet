// Initialisation des bibliot�ques
using System;
using System.IO;
using System.Collections.Generic;

namespace Interface_connexion
{
    public partial class Form_connexion : Form
    {
        public Form_connexion()
        {
            InitializeComponent();
        }

        // Si le bouton valider est cliqu�
        private void btn_valider_Click(object sender, EventArgs e)
        {
            Verif_connexion();
        }

        private void tB_mot_de_passe_TextChanged(object sender, EventArgs e)
        {
            // Cacher le mot de passe avec des "�"
            tB_mot_de_passe.PasswordChar = '�';

            // Si les zones de matricule et de mot de passe ne sont pas vides
            if (tB_matricule.Text != "" && tB_mot_de_passe.Text != "")
            {
                // On d�grise le bouton valider
                btn_valider.Enabled = true;
            }

            // Si la zone de mot de passe est vide
            else
            {
                // On grise le bouton valider
                btn_valider.Enabled = false;
            }
        }


        private void Verif_connexion()
        {
            // Pour le Matricule

            // Recherche du fichier CSV
            var reader = new StreamReader(File.OpenRead(@"../../../digicod_perso.csv"));

            // Valeurs bool�ennes pour les conditions plus tard
            bool matricule_correct = false;
            bool mot_de_passe_correct = false;
            bool date_correct = false;

            string matricule;

            List<string> listA = new List<string>();
            List<string> listB = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();

                // On split les valeurs s�par�es par des ";" dans le fichier CSV
                var values = line.Split(';');

                // Pour se mettre dans la colonne 4 de la feuille Excel (n+1)
                listA.Add(values[3]);

                // Pour se mettre dans la colonne 1 de la feuille Excel (n+1)
                listB.Add(values[0]);

                // Boucle qui parcours toutes les lignes de la feuille
                for (int i = 0; i < listA.Count; i++)
                {
                    string recherche_T = listA[i];
                    // Si on trouve un "T" dans la troisi�me colonne
                    if (recherche_T == "T")
                    {
                        matricule = listB[i];
                        // Si on entre le bon matricule
                        if (tB_matricule.Text == matricule)
                        {
                            matricule_correct = true;
                        }

                        else
                        {
                            matricule_correct = false;
                        }
                    }
                }
            }




            // Pour le Mot de passe

            // Recherche du fichier CSV
            var reader1 = new StreamReader(File.OpenRead(@"../../../digicod_secure.csv"));

            string mot_de_passe;

            List<string> listC = new List<string>();
            List<string> listD = new List<string>();
            List<string> listE = new List<string>();

            // Date en temps r�el
            var date = DateTime.Now.ToString("dd/MM/yyyy");

            while (!reader1.EndOfStream)
            {
                var line = reader1.ReadLine();

                // On split les valeurs s�par�es par des ";" dans le fichier CSV
                var values = line.Split(';');

                // Pour se mettre dans la colonne 1 de la feuille Excel (n+1)
                listC.Add(values[0]);

                // Pour se mettre dans la colonne 4 de la feuille Excel (n+1)
                listD.Add(values[3]);

                // Pour se mettre dans la colonne 3 de la feuille Excel (n+1)
                listE.Add(values[2]);

                // Boucle qui parcours toutes les lignes de la feuille 
                for (int i = 0; i < listC.Count; i++)
                {
                    string recherche_T = listC[i];
                    // Si on trouve un "T" dans la premi�re colonne
                    if (recherche_T == "T")
                    {
                        mot_de_passe = listD[i];
                        var date_fin = listE[i];

                        // Si on entre le bon mot de passe
                        if (tB_mot_de_passe.Text == mot_de_passe)
                        {
                            mot_de_passe_correct = true;
                        }

                        else
                        {
                            mot_de_passe_correct = false;
                        }

                        // On compare les deux derniers chiffres du mois actuel et du mois
                        // de la date de fin du mot de passe
                        if (DateTime.Parse(date) < DateTime.Parse(date_fin))
                        {
                            date_correct = true;
                        }

                        else
                        {
                            date_correct = false;
                        }
                    }
                }
            }
            reader1.Close();

            // Si le matricule et le mot de passe entr�s sont corrects
            if (matricule_correct == true && mot_de_passe_correct == true && date_correct == true)
            {
                Form_Menu_Cryptage X = new Form_Menu_Cryptage();
                X.ShowDialog();
                this.Close();
            }

            // Si le matricule et le mot de passe entr�s sont corrects mais que le mot de passe a expir�
            else if (matricule_correct == true && mot_de_passe_correct == true && date_correct == false)
            {
                // On affiche un message d'alerte
                MessageBox.Show("Ce mot de passe n'est plus � jour !");

                // On clear les zones de matricule et de mot de passe
                tB_matricule.Clear();
                tB_mot_de_passe.Clear();
            }

            // Si le matricule et le mot de passe entr�s sont incorrects
            else if (matricule_correct == false && mot_de_passe_correct == false)
            {
                // On affiche un message d'alerte
                MessageBox.Show("Matricule et mot de passe incorrects !");

                // On clear les zones de matricule et de mot de passe
                tB_matricule.Clear();
                tB_mot_de_passe.Clear();
            }

            // Si le mot de passe entr� est incorrect
            else if (mot_de_passe_correct == false)
            {
                // On affiche un message d'alerte
                MessageBox.Show("Mot de passe incorrect !");

                // On clear la zone de mot de passe
                tB_mot_de_passe.Clear();
            }

            // Si le matricule entr� est incorrect
            else if (matricule_correct == false)
            {
                // On affiche un message d'alerte
                MessageBox.Show("Matricule incorrect !");

                // On clear la zone de matricule
                tB_matricule.Clear();
            }
        }

        private void tB_matricule_TextChanged(object sender, EventArgs e)
        {
            // Si les zones de matricule et de mot de passe ne sont pas vides
            if (tB_matricule.Text != "" && tB_mot_de_passe.Text != "")
            {
                // On d�grise le bouton valider
                btn_valider.Enabled = true;
            }

            // Si la zone de mot de passe est vide
            else
            {
                // On grise le bouton valider
                btn_valider.Enabled = false;
            }
        }

        private void Form_connexion_Load(object sender, EventArgs e)
        {
            // Date en temps r�el
            string date_reel = DateTime.Now.ToString("dd/MM/yyyy");
            int jour = Convert.ToInt32(date_reel.Substring(0, 2));

            // Si la date du jour est sup�rieure ou �gale au 27 du mois
            if (jour >= 27)
            {
                // Ouverture d'un message d'alerte
                MessageBox.Show("Il ne vous reste que quelques jours pour changer les mots de passe !");
            }
        }
    }
}