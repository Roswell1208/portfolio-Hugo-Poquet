﻿namespace Interface_connexion
{
    partial class Form_Cryptage_Salle_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Cryptage_Salle_Info));
            this.label3 = new System.Windows.Forms.Label();
            this.btn_crypter = new System.Windows.Forms.Button();
            this.btn_enregistrer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tB_mot_de_passe_crypte = new System.Windows.Forms.TextBox();
            this.tB_mot_de_passe = new System.Windows.Forms.TextBox();
            this.btn_retour = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_nouveau = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(65, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(682, 28);
            this.label3.TabIndex = 15;
            this.label3.Text = "Bienvenue sur la page de cryptage des mots de passe de la salle informatique";
            // 
            // btn_crypter
            // 
            this.btn_crypter.BackColor = System.Drawing.Color.White;
            this.btn_crypter.Location = new System.Drawing.Point(322, 188);
            this.btn_crypter.Name = "btn_crypter";
            this.btn_crypter.Size = new System.Drawing.Size(160, 63);
            this.btn_crypter.TabIndex = 14;
            this.btn_crypter.Text = "Crypter le mot de passe";
            this.btn_crypter.UseVisualStyleBackColor = false;
            this.btn_crypter.Click += new System.EventHandler(this.btn_crypter_Click);
            // 
            // btn_enregistrer
            // 
            this.btn_enregistrer.BackColor = System.Drawing.Color.White;
            this.btn_enregistrer.Location = new System.Drawing.Point(65, 348);
            this.btn_enregistrer.Name = "btn_enregistrer";
            this.btn_enregistrer.Size = new System.Drawing.Size(160, 63);
            this.btn_enregistrer.TabIndex = 13;
            this.btn_enregistrer.Text = "Enregistrer";
            this.btn_enregistrer.UseVisualStyleBackColor = false;
            this.btn_enregistrer.Click += new System.EventHandler(this.btn_enregistrer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(133, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Mot de passe crypté :";
            // 
            // tB_mot_de_passe_crypte
            // 
            this.tB_mot_de_passe_crypte.BackColor = System.Drawing.SystemColors.Window;
            this.tB_mot_de_passe_crypte.Location = new System.Drawing.Point(307, 295);
            this.tB_mot_de_passe_crypte.Name = "tB_mot_de_passe_crypte";
            this.tB_mot_de_passe_crypte.ReadOnly = true;
            this.tB_mot_de_passe_crypte.Size = new System.Drawing.Size(193, 27);
            this.tB_mot_de_passe_crypte.TabIndex = 11;
            // 
            // tB_mot_de_passe
            // 
            this.tB_mot_de_passe.Location = new System.Drawing.Point(307, 128);
            this.tB_mot_de_passe.Name = "tB_mot_de_passe";
            this.tB_mot_de_passe.Size = new System.Drawing.Size(193, 27);
            this.tB_mot_de_passe.TabIndex = 10;
            this.tB_mot_de_passe.TextChanged += new System.EventHandler(this.tB_mot_de_passe_TextChanged);
            // 
            // btn_retour
            // 
            this.btn_retour.BackColor = System.Drawing.Color.White;
            this.btn_retour.Location = new System.Drawing.Point(576, 348);
            this.btn_retour.Name = "btn_retour";
            this.btn_retour.Size = new System.Drawing.Size(160, 63);
            this.btn_retour.TabIndex = 9;
            this.btn_retour.Text = "Retour";
            this.btn_retour.UseVisualStyleBackColor = false;
            this.btn_retour.Click += new System.EventHandler(this.btn_retour_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(255, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Veuillez entrer un mot de passe à crypter :";
            // 
            // btn_nouveau
            // 
            this.btn_nouveau.BackColor = System.Drawing.Color.White;
            this.btn_nouveau.Location = new System.Drawing.Point(322, 348);
            this.btn_nouveau.Name = "btn_nouveau";
            this.btn_nouveau.Size = new System.Drawing.Size(160, 63);
            this.btn_nouveau.TabIndex = 16;
            this.btn_nouveau.Text = "Nouveau";
            this.btn_nouveau.UseVisualStyleBackColor = false;
            this.btn_nouveau.Click += new System.EventHandler(this.btn_nouveau_Click);
            // 
            // Form_Cryptage_Salle_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_nouveau);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_crypter);
            this.Controls.Add(this.btn_enregistrer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tB_mot_de_passe_crypte);
            this.Controls.Add(this.tB_mot_de_passe);
            this.Controls.Add(this.btn_retour);
            this.Controls.Add(this.label1);
            this.Name = "Form_Cryptage_Salle_Info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cryptage Accès Salle Informatique";
            this.Load += new System.EventHandler(this.Form_Cryptage_Salle_Info_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label3;
        private Button btn_crypter;
        private Button btn_enregistrer;
        private Label label2;
        private TextBox tB_mot_de_passe_crypte;
        private TextBox tB_mot_de_passe;
        private Button btn_retour;
        private Label label1;
        private Button btn_nouveau;
    }
}