﻿// Initialisation des bibliotèques
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface_connexion
{
    public partial class Form_Cryptage_Batiment : Form
    {
        bool mot_de_passe_ok = false;
        bool date_ok = true;

        public Form_Cryptage_Batiment()
        {
            InitializeComponent();
        }

        private void Form_Cryptage_Batiment_Load(object sender, EventArgs e)
        {
            // On grise les boutons crypter et enregistrer à l'ouverture
            btn_crypter.Enabled = false;
            btn_enregistrer.Enabled = false;
        }

        // Si le bouton retour est cliqué
        private void btn_retour_Click(object sender, EventArgs e)
        {
            // On retourne au menu
            Form_Menu_Cryptage X = new Form_Menu_Cryptage();
            X.ShowDialog();
            this.Close();
        }

        private void tB_mot_de_passe_TextChanged(object sender, EventArgs e)
        {
            // Si la longueur du mot de passe est respectée
            if (tB_mot_de_passe.Text.Length == 6)
            {
                // On dégrise le bouton crytper
                btn_crypter.Enabled = true;
            }

            // Sinon il reste grisé
            else
            {
                btn_crypter.Enabled = false;
            }


            // Vérification des caractères entrés
            // Si les caractères entrés ne sont que des lettres majuscules ou minuscules
            if (System.Text.RegularExpressions.Regex.IsMatch(tB_mot_de_passe.Text, "^[a-zA-Z]+$"))
            {
                // Le mot de passe est valide
                mot_de_passe_ok = true;
            }

            // Sinon on affiche une alerte et on retire le dernier caractère de la textbox
            else if (tB_mot_de_passe.Text.Length > 1)
            {
                tB_mot_de_passe.Text = tB_mot_de_passe.Text.Remove(tB_mot_de_passe.Text.Length - 1);
                MessageBox.Show("Ce type de caractère n'est pas autorisé !");
            }

            // S'il n'y a qu'un seul caractère dans la textbox, pour éviter des erreurs, on la vide
            else
            {
                tB_mot_de_passe.Clear();
                MessageBox.Show("Ce type de caractère n'est pas autorisé !");
            }
        }


        // Cryptage du mot de passe
        private void btn_crypter_Click(object sender, EventArgs e)
        {
            btn_crypter.Enabled = false;
            btn_enregistrer.Enabled = true;
            tB_mot_de_passe.Enabled = false;

            // Initialisation d'un alphabet
            string[] alphabet = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
                "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};


            // Si le mot de passe entré est valide
            if (mot_de_passe_ok == true)
            {
                string mot = tB_mot_de_passe.Text;
                string mot_code = "";

                // Codage du mot de passe en le parcourant
                for (int i = 0; i < mot.Length; i++)
                {
                    for (int j = 0; j < alphabet.Length; j++)
                    {
                        if (Convert.ToString(mot[i]) == alphabet[j])
                        {
                            mot_code += alphabet[(j + 10) % 26];
                        }
                    }
                }

                // On met tous les caractères en majuscule
                tB_mot_de_passe_crypte.Text = mot_code.ToUpper();
            }
        }

        private void btn_enregistrer_Click(object sender, EventArgs e)
        {
            verif_date();

            if (date_ok == true)
            {
                btn_enregistrer.Enabled = false;
                MessageBox.Show("Mot de passe pour l'accès au bâtiment enregistré !");

                // Date en temps réel
                var date = DateTime.Now;

                var date_debut = date.Date.ToString("01-MM-yyyy");
                var date_fin = date.ToString(DateTime.DaysInMonth(date.Year, date.Month) + "-MM-yyyy");

                // Ecriture dans le fichier
                using (StreamWriter writer =
                    new StreamWriter(@"../../../digicod_secure.csv", true))
                {
                    writer.WriteLine("E;" + date_debut + ";" + date_fin + ";" + tB_mot_de_passe_crypte.Text);
                }
            }

            else if (date_ok == false)
            {
                MessageBox.Show("Vous avez déjà entré un mot de passe pour l'accès au bâtiment ce mois-ci");
            }
        }


        // Fonction de vérification pour s'assurer qu'il n'y a bien eu qu'une seule
        // diffusion de mot de passe ce mois-ci
        private void verif_date()
        {
            // Pour la date de fin

            // Recherche du fichier CSV
            var reader = new StreamReader(File.OpenRead(@"../../../digicod_secure.csv"));


            string date_actuelle = DateTime.Now.ToString("dd/MM/yyyy");
            int mois_actuel = Convert.ToInt32(date_actuelle.Substring(3, 2));
            int annee_actuelle = Convert.ToInt32(date_actuelle.Substring(6, 2));

            List<string> listA = new List<string>();
            List<string> listB = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();

                // On split les valeurs séparées par des ";" dans le fichier CSV
                var values = line.Split(';');

                // Pour se mettre dans la colonne 1 de la feuille Excel (n+1)
                listA.Add(values[0]);

                // Pour se mettre dans la colonne 3 de la feuille Excel (n+1)
                listB.Add(values[2]);

                // Boucle qui parcours toutes les lignes de la feuille
                for (int i = 1; i < listB.Count; i++)
                {
                    // Si on trouve déjà un mot de passe pour le mois et que l'autorisation est "E"
                    if (DateTime.Parse(date_actuelle) <= DateTime.Parse(listB[i]) && listA[i] == "E")
                    {
                        date_ok = false;
                    }

                    // Sinon la date est ok
                    else
                    {
                        date_ok = true;
                    }
                }
            }
            reader.Close();
        }

        private void btn_nouveau_Click(object sender, EventArgs e)
        {
            // Si le bouton nouveau est cliqué, on recharge la page
            Form_Cryptage_Batiment X = new Form_Cryptage_Batiment();
            X.ShowDialog();
            this.Close();
        }
    }
}
