﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface_connexion
{
    public partial class Form_Menu_Cryptage : Form
    {
        public Form_Menu_Cryptage()
        {
            InitializeComponent();
        }

        private void Form_Menu_Cryptage_Load(object sender, EventArgs e)
        {

        }

        private void btn_crypter_batiment_Click(object sender, EventArgs e)
        {
            Form_Cryptage_Batiment X = new Form_Cryptage_Batiment();
            X.ShowDialog();
            this.Close();
        }

        private void btn_crypter_salle_info_Click(object sender, EventArgs e)
        {
            Form_Cryptage_Salle_Info X = new Form_Cryptage_Salle_Info();
            X.ShowDialog();
            this.Close();
        }

        private void btn_quitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
