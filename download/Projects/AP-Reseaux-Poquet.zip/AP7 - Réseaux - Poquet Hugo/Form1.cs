﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP7___Réseaux___Poquet_Hugo
{
    public partial class Form1 : Form
    {
        int CIDR_Cal;
        string masque0;
        string masque1;
        string masque2;
        string masque3;
        int nbr_hotes;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button_valider.Enabled = false;
        }

        private void adresse_octet1_TextChanged(object sender, EventArgs e)
        {
            if (adresse_IP.Text != "")
            {
                button_valider.Enabled = true;
            }

            else
            {
                button_valider.Enabled = false;
            }
        }

        private void button_valider_Click(object sender, EventArgs e)
        {
            /* Conversion de l'adresse IP en binaire */
            
            String[] IP = adresse_IP.Text.Split('.');

            int value0 = int.Parse(IP[0]);
            Int16 numBase = 2;
            string number0 = Convert.ToString(value0, numBase);

            int value1 = int.Parse(IP[1]);
            string number1 = Convert.ToString(value1, numBase);

            int value2 = int.Parse(IP[2]);
            string number2 = Convert.ToString(value2, numBase);

            int value3 = int.Parse(IP[3]);
            string number3 = Convert.ToString(value3, numBase);

            /* Vérification pour ne pas dépasser 255 pour chaque octet */

            if (value0 > 255)
            {
                this.Close();
            }

            else if (value1 > 255)
            {
                this.Close();
            }

            else if (value2 > 255)
            {
                this.Close();
            }

            else if (value3 > 255)
            {
                this.Close();
            }

            /* Affichage de l'adresse IP en binaire */
            resultat.Text = number0 + "." + number1 + "." + number2 + "." + number3;

            /* Calcul du masque en fonction du CIDR */
            string[] tab = new string[8] { "10000000", "11000000", "11100000", "11110000", "11111000", "11111100", "11111110", "11111111" };

            int CIDR_Cal = Decimal.ToInt32(CIDR.Value);

            if (CIDR_Cal <= 8)
            {
                int i = CIDR_Cal - 1;

                masque0 = tab[i];
                masque1 = "00000000";
                masque2 = "00000000";
                masque3 = "00000000";
            }

            else if (CIDR_Cal <= 16)
            {
                int i = CIDR_Cal - 8 - 1;

                masque0 = "11111111";
                masque1 = tab[i];
                masque2 = "00000000";
                masque3 = "00000000";
            }

            else if (CIDR_Cal <= 24)
            {
                int i = CIDR_Cal - 16 - 1;

                masque0 = "11111111";
                masque1 = "11111111";
                masque2 = tab[i];
                masque3 = "00000000";
            }

            else if (CIDR_Cal <= 32)
            {
                int i = CIDR_Cal - 24 - 1;

                masque0 = "11111111";
                masque1 = "11111111";
                masque2 = "11111111";
                masque3 = tab[i];
            }

            masque_bin.Text = masque0 + "." + masque1 + "." + masque2 + "." + masque3;

            /* Conversion du masque en base 10 */
            Int16 numBase2 = 2;
            string valeur0 = masque0;
            byte nbr0 = Convert.ToByte(valeur0, numBase2);

            string valeur1 = masque1;
            byte nbr1 = Convert.ToByte(valeur1, numBase2);

            string valeur2 = masque2;
            byte nbr2 = Convert.ToByte(valeur2, numBase2);

            string valeur3 = masque3;
            byte nbr3 = Convert.ToByte(valeur3, numBase2);

            masque_dec.Text = Convert.ToString(nbr0) + "." + Convert.ToString(nbr1) + "." + Convert.ToString(nbr2) + "." + Convert.ToString(nbr3);

            /* Trouver le nombre d'hôtes maximum du réseau */
            double nbr_hotes = 0;
            nbr_hotes = Math.Pow(2,(32 - Decimal.ToDouble(CIDR.Value))) - 2;

            hotes.Text = Convert.ToString(nbr_hotes);
        }

        private void button_quitter_Click(object sender, EventArgs e)
        {
            /* Ferme la page quand on clique sur le bouton */
            this.Close();
        }

        private void button_recommencer_Click(object sender, EventArgs e)
        {
            /* Nettoyage des TextBox */
            adresse_IP.Clear();
            resultat.Clear();
            masque_dec.Clear();
            masque_bin.Clear();
            hotes.Clear();
        }
    }
}
