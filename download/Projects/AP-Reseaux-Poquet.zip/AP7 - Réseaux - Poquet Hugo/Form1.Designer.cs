﻿
namespace AP7___Réseaux___Poquet_Hugo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.adresse_IP = new System.Windows.Forms.TextBox();
            this.button_valider = new System.Windows.Forms.Button();
            this.resultat = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CIDR = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.masque_dec = new System.Windows.Forms.TextBox();
            this.masque_bin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.hotes = new System.Windows.Forms.TextBox();
            this.button_recommencer = new System.Windows.Forms.Button();
            this.button_quitter = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CIDR)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adresse IP :";
            // 
            // adresse_IP
            // 
            this.adresse_IP.Location = new System.Drawing.Point(163, 34);
            this.adresse_IP.Name = "adresse_IP";
            this.adresse_IP.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adresse_IP.Size = new System.Drawing.Size(290, 27);
            this.adresse_IP.TabIndex = 1;
            this.adresse_IP.TextChanged += new System.EventHandler(this.adresse_octet1_TextChanged);
            // 
            // button_valider
            // 
            this.button_valider.Location = new System.Drawing.Point(527, 89);
            this.button_valider.Name = "button_valider";
            this.button_valider.Size = new System.Drawing.Size(142, 52);
            this.button_valider.TabIndex = 8;
            this.button_valider.Text = "Valider";
            this.button_valider.UseVisualStyleBackColor = true;
            this.button_valider.Click += new System.EventHandler(this.button_valider_Click);
            // 
            // resultat
            // 
            this.resultat.Location = new System.Drawing.Point(304, 170);
            this.resultat.Name = "resultat";
            this.resultat.ReadOnly = true;
            this.resultat.Size = new System.Drawing.Size(394, 27);
            this.resultat.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(85, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "CIDR :";
            // 
            // CIDR
            // 
            this.CIDR.Location = new System.Drawing.Point(163, 76);
            this.CIDR.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.CIDR.Name = "CIDR";
            this.CIDR.Size = new System.Drawing.Size(125, 27);
            this.CIDR.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "Adresse IP Binaire :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 223);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(238, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Masque de sous-réseau (décimal) :";
            // 
            // masque_dec
            // 
            this.masque_dec.Location = new System.Drawing.Point(304, 220);
            this.masque_dec.Name = "masque_dec";
            this.masque_dec.ReadOnly = true;
            this.masque_dec.Size = new System.Drawing.Size(394, 27);
            this.masque_dec.TabIndex = 14;
            // 
            // masque_bin
            // 
            this.masque_bin.Location = new System.Drawing.Point(304, 274);
            this.masque_bin.Name = "masque_bin";
            this.masque_bin.ReadOnly = true;
            this.masque_bin.Size = new System.Drawing.Size(394, 27);
            this.masque_bin.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Masque de sous-réseau (binaire) :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 326);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Nombre d\'hôtes max du réseau :";
            // 
            // hotes
            // 
            this.hotes.Location = new System.Drawing.Point(304, 326);
            this.hotes.Name = "hotes";
            this.hotes.ReadOnly = true;
            this.hotes.Size = new System.Drawing.Size(394, 27);
            this.hotes.TabIndex = 18;
            // 
            // button_recommencer
            // 
            this.button_recommencer.Location = new System.Drawing.Point(135, 379);
            this.button_recommencer.Name = "button_recommencer";
            this.button_recommencer.Size = new System.Drawing.Size(168, 50);
            this.button_recommencer.TabIndex = 19;
            this.button_recommencer.Text = "Recommencer";
            this.button_recommencer.UseVisualStyleBackColor = true;
            this.button_recommencer.Click += new System.EventHandler(this.button_recommencer_Click);
            // 
            // button_quitter
            // 
            this.button_quitter.Location = new System.Drawing.Point(478, 379);
            this.button_quitter.Name = "button_quitter";
            this.button_quitter.Size = new System.Drawing.Size(168, 50);
            this.button_quitter.TabIndex = 20;
            this.button_quitter.Text = "Quitter";
            this.button_quitter.UseVisualStyleBackColor = true;
            this.button_quitter.Click += new System.EventHandler(this.button_quitter_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_quitter);
            this.Controls.Add(this.button_recommencer);
            this.Controls.Add(this.hotes);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.masque_bin);
            this.Controls.Add(this.masque_dec);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CIDR);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.resultat);
            this.Controls.Add(this.button_valider);
            this.Controls.Add(this.adresse_IP);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CIDR)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox adresse_IP;
        private System.Windows.Forms.Button button_valider;
        private System.Windows.Forms.TextBox resultat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown CIDR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox masque_dec;
        private System.Windows.Forms.TextBox masque_bin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox hotes;
        private System.Windows.Forms.Button button_recommencer;
        private System.Windows.Forms.Button button_quitter;
    }
}

