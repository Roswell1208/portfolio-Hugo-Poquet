
      <div class="home">
          <div id="Home_title_ss">
              <div id="Titles">
                  <?php echo $message ; ?>
              </div>
          </div>
      </div>