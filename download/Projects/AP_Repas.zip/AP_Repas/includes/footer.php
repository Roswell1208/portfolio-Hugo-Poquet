 </div>
</div>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="/assets/js/vendor/jquery.min.js"><\/script>');</script>
    <script src="includes/js/bootstrap.min.js"></script>
    <script src="includes/js/jquery-ui.min.js"></script>
    <script src="includes/js/browserscript.js"></script>
    <script src="includes/js/bodymovin.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="includes/js/fonctions.js"></script>
</body>
</html>