-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mar 17 Mai 2022 à 15:52
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `dbrepas`
--

-- --------------------------------------------------------

--
-- Structure de la table `elior_utilisateur`
--

CREATE TABLE IF NOT EXISTS `elior_utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL DEFAULT '',
  `idClasse` int(11) NOT NULL DEFAULT '0',
  `login` varchar(25) NOT NULL DEFAULT '',
  `mdp` varchar(255) NOT NULL DEFAULT '',
  `statut` int(11) NOT NULL DEFAULT '0',
  `creditRepas` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

--
-- Contenu de la table `elior_utilisateur`
--

INSERT INTO `elior_utilisateur` (`id`, `nom`, `prenom`, `idClasse`, `login`, `mdp`, `statut`, `creditRepas`) VALUES
(9, 'BOETE', 'Antoine', 2, 'BOETEA', '1a1dc91c907325c69271ddf0c944bc72', 1, 9),
(10, 'CHAPELAIN', 'Gael', 1, 'CHAPELAING', '1a1dc91c907325c69271ddf0c944bc72', 1, 30.75),
(11, 'DA SILVA MARQUES', 'Lucas', 1, 'DASILVAL', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(12, 'BOUMADAFA', 'Marouane', 1, 'BOUMADAFAM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(13, 'BOUSSAIDA', 'Sofiene', 2, 'BOUSSAIDAS', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(14, 'CATROUILLET', 'Jonas', 1, 'CATROUILLETJ', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(15, 'KONARSKI', 'Matthieu', 2, 'KONARSKIM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(16, 'MARTINET', 'Clement', 1, 'MARTINETC', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(17, 'LECOMTE', 'Bryan', 1, 'LECOMTEB', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(18, 'LE GARFF', 'Kevin', 2, 'LEGARFFK', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(19, 'LECOUBLET', 'Theo', 1, 'LECOUBLETT', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(21, 'LE DUC', 'Pierre', 1, 'LEDUCP', '1a1dc91c907325c69271ddf0c944bc72', 1, 3),
(22, 'LACINGA', 'Corentin', 2, 'LACINGAC', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(24, 'DOUBLEAU', 'Quentin', 1, 'DOUBLEAUQ', '1a1dc91c907325c69271ddf0c944bc72', 1, 2),
(25, 'VARILLON', 'Anthony', 2, 'VARILLONA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(26, 'DZOGANG', 'Sami', 1, 'DZOGANGS', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(27, 'FONTAN', 'Gaetan', 1, 'FONTANG', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(28, 'DE SISTO', 'Lorenzo', 1, 'DESISTOL', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(29, 'CARRE', 'Arthur', 1, 'CARREA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(31, 'DENONCIN', 'Agnès', 0, 'DENONCINA', '1a1dc91c907325c69271ddf0c944bc72', 2, 0),
(32, 'RUGGERI', 'Anthony', 2, 'RUGGERIA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(33, 'DESNOS', 'Remi', 2, 'DESNOSR', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(34, 'ITTOHEMAD', 'Meryeme', 2, 'ITTOHEMADM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0.5),
(35, 'GROMER', 'Johan', 1, 'GROMERJ', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(36, 'JOURDAIN', 'Esteban', 2, 'JOURDAINE', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(37, 'GRATIEN', 'Erwann', 1, 'GRATIENE', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(38, 'BOULANGER', 'Florian', 2, 'BOULANGERF', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(39, 'QUENOT', 'Mael', 2, 'QUENOTM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(40, 'THOMAS', 'Alexis', 2, 'THOMASA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(41, 'DOSTE MOHAMED', 'Yohann', 2, 'DOSTEY', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(42, 'MOREL', 'Teddy', 2, 'MORELT', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(43, 'DANG', 'Mathieu', 1, 'DANGM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(44, 'DJENADI', 'Axel', 2, 'DJENADIA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(45, 'AUBERTIN', 'Gregoire', 1, 'AUBERTING', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(46, 'DUPREY', 'Clement', 2, 'DUPREYC', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(47, 'LEDRU', 'Maxime', 2, 'LEDRUM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(48, 'INAN', 'Anysse', 2, 'INANA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(49, 'LETORT', 'Samuel', 2, 'LETORTS', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(50, 'MESLIN', 'Thibaut', 1, 'MESLINT', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(51, 'KAUFFMANNN', 'Nathan', 1, 'KAUFFMANN', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(52, 'MUSEUX', 'Remi', 2, 'MUSEUXR', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(53, 'BALLOT', 'Dimitry', 2, 'BALLOTD', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(54, 'GERBE', 'Benjamin', 1, 'GERBEB', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(55, 'PIROU', 'Paul', 2, 'PIROUP', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(56, 'HAUTCOEUR', 'Jules', 1, 'HAUTCOEURJ', '1a1dc91c907325c69271ddf0c944bc72', 1, 18),
(57, 'HUE', 'Mathias', 1, 'HUEM', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(58, 'KARAKUS', 'Yasin', 1, 'KARAKUSY', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(59, 'DELATOUCHE', 'Romain', 2, 'DELATOUCHER', '1a1dc91c907325c69271ddf0c944bc72', 1, 1),
(60, 'LEGOUPIL', 'William', 2, 'LEGOUPILW', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(61, 'HATCHUEL', 'Jules', 2, 'HATCHUELJ', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(62, 'BELABASSI', 'Omar', 2, 'BELABASSIO', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(63, 'MOUQUET', 'Adrien', 1, 'MOUQUETA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(64, 'NAZIL', 'Ilyes', 1, 'NAZILI', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(65, 'PAUL', 'Timothee', 1, 'PAULT', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(66, 'PHILIPPE', 'Kevin', 1, 'PHILIPPEK', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(67, 'ROGER', 'Remi', 1, 'ROGERR', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(68, 'SIMONEAU', 'Quentin', 1, 'SIMONEAUQ', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(69, 'SONTOT', 'Alexis', 1, 'SONTOTA', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(70, 'SOULIVET', 'Victor', 1, 'SOULIVETV', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(71, 'ZIANI', 'Yanis', 1, 'ZIANIY', '1a1dc91c907325c69271ddf0c944bc72', 1, 0),
(72, 'ELIOR', '', 0, 'ELIOR', '1a1dc91c907325c69271ddf0c944bc72', 4, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
