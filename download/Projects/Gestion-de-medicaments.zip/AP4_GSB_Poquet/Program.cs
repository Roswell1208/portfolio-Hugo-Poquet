﻿using System;

namespace AP4_GSB_Poquet
{
    class Program
    {
        static void Main(string[] args)
        {
            string demande;
            bool continuer = true;

            bool medicament = true;
            bool medicament2;

            bool vente = true;
            bool vente2;

            bool doliprane;
            bool ibuprofene;
            bool efferalgan;
            bool spasfon;

            char type;

            int quantite_doliprane = 0;
            int quantite_ibuprofene = 0;
            int quantite_efferalgan = 0;
            int quantite_spasfon = 0;

            int quantite_doliprane_vente = 0;
            int quantite_ibuprofene_vente = 0;
            int quantite_efferalgan_vente = 0;
            int quantite_spasfon_vente = 0;

            int prix_doliprane = 0;
            int prix_ibuprofene = 0;
            int prix_efferalgan = 0;
            int prix_spasfon = 0;

            Console.WriteLine("Bienvenue");
            Console.WriteLine("Pour ajouter des médicaments au stock, tapez AV");
            Console.WriteLine("Pour vendre des médicaments, tapez VM");
            Console.WriteLine("Pour visualiser le stock, tapez VS");
            Console.WriteLine("Pour quitter la console, tapez stop");

            while (continuer == true)
            {
                Console.WriteLine("Que voulez-vous faire ?");
                demande = Console.ReadLine();


                /* Ajout de médicaments en stock */

                if (demande == "AV")
                {
                    doliprane = true;
                    ibuprofene = true;
                    efferalgan = true;
                    spasfon = true;

                    while (medicament == true)
                    {
                        Console.WriteLine("Voulez-vous ajouter un médicament au stock ? Si oui true sinon false");
                        medicament2 = bool.Parse(Console.ReadLine());

                        if (medicament2 == false)
                        {
                            medicament = false;
                        }

                        else
                        {
                            Console.WriteLine("Quel type de médicament voulez-vous ajouter au stock ?");
                            type = char.Parse(Console.ReadLine());


                            /* Pour le doliprane */

                            if (type == 'D' && doliprane == true)
                            {
                                Console.WriteLine("Quelle quantité de doliprane voulez-vous ?");
                                quantite_doliprane = int.Parse(Console.ReadLine());
                                doliprane = false;
                            }

                            else if (type == 'D' && doliprane == false)
                            {
                                Console.WriteLine("Vous avez déjà entré du doliprane.");
                            }


                            /* Pour l'ibuprofene */

                            else if (type == 'I' && ibuprofene == true)
                            {
                                Console.WriteLine("Quelle quantité d'ibuprofene voulez-vous ?");
                                quantite_ibuprofene = int.Parse(Console.ReadLine());
                                ibuprofene = false;
                            }

                            else if (type == 'I' && ibuprofene == false)
                            {
                                Console.WriteLine("Vous avez déjà entré de l'ibuprofene.");
                            }


                            /* Pour l'efferalgan */

                            else if (type == 'E' && efferalgan == true)
                            {
                                Console.WriteLine("Quelle quantité d'efferalgan voulez-vous ?");
                                quantite_efferalgan = int.Parse(Console.ReadLine());
                                efferalgan = false;
                            }

                            else if (type == 'E' && efferalgan == false)
                            {
                                Console.WriteLine("Vous avez déjà entré de l'efferalgan.");
                            }


                            /* Pour le spasfon */

                            else if (type == 'S' && spasfon == true)
                            {
                                Console.WriteLine("Quelle quantité de spasfon voulez-vous ?");
                                quantite_spasfon = int.Parse(Console.ReadLine());
                                spasfon = false;
                            }

                            else if (type == 'S' && spasfon == false)
                            {
                                Console.WriteLine("Vous avez déjà entré du spasfon.");
                            }

                            else
                            {
                                Console.WriteLine("Ce médicament n'est pas dans notre base de données");
                            }
                        }
                    }
                    Console.WriteLine("Vous avez entré : " + quantite_doliprane + " doliprane, " + quantite_ibuprofene + " ibuprofene, " + quantite_efferalgan + " efferalgan, " + quantite_spasfon + " spasfon.");
                    medicament = true;
                }


                /* Vendre un médicament */

                else if (demande == "VM")
                {
                    if (quantite_doliprane != 0 || quantite_ibuprofene != 0 || quantite_efferalgan != 0 || quantite_spasfon != 0)
                    {
                        while (vente == true)
                        {
                            Console.WriteLine("Voulez-vous vendre un médicament ? Si oui true sinon false");
                            vente2 = bool.Parse(Console.ReadLine());

                            if (vente2 == false)
                            {
                                vente = false;
                            }

                            else
                            {
                                Console.WriteLine("Quel type de médicament voulez-vous vendre ?");
                                type = char.Parse(Console.ReadLine());


                                /* Pour le doliprane */

                                if (type == 'D' && quantite_doliprane != 0)
                                {
                                    Console.WriteLine("Quelle quantité de doliprane voulez-vous vendre ?");
                                    quantite_doliprane_vente = int.Parse(Console.ReadLine());

                                    if (quantite_doliprane_vente > quantite_doliprane)
                                    {
                                        Console.WriteLine("Stock insuffisant");
                                    }

                                    else
                                    {
                                        quantite_doliprane -= quantite_doliprane_vente;

                                        Console.WriteLine("A combien voulez-vous vendre le doliprane ?");
                                        prix_doliprane = int.Parse(Console.ReadLine());
                                    }
                                }


                                /* Pour l'ibuprofene */

                                if (type == 'I' && quantite_ibuprofene != 0)
                                {
                                    Console.WriteLine("Quelle quantité d'ibuprofene voulez-vous vendre ?");
                                    quantite_ibuprofene_vente = int.Parse(Console.ReadLine());

                                    if (quantite_ibuprofene_vente > quantite_ibuprofene)
                                    {
                                        Console.WriteLine("Stock insuffisant");
                                    }

                                    else
                                    {
                                        quantite_ibuprofene -= quantite_ibuprofene_vente;

                                        Console.WriteLine("A combien voulez-vous vendre l'ibuprofene ?");
                                        prix_ibuprofene = int.Parse(Console.ReadLine());
                                    }
                                }


                                /* Pour l'efferalgan */

                                if (type == 'E' && quantite_efferalgan != 0)
                                {
                                    Console.WriteLine("Quelle quantité d'efferalgan voulez-vous vendre ?");
                                    quantite_efferalgan_vente = int.Parse(Console.ReadLine());

                                    if (quantite_efferalgan_vente > quantite_efferalgan)
                                    {
                                        Console.WriteLine("Stock insuffisant");
                                    }

                                    else
                                    {
                                        quantite_efferalgan -= quantite_efferalgan_vente;

                                        Console.WriteLine("A combien voulez-vous vendre l'efferalgan ?");
                                        prix_efferalgan = int.Parse(Console.ReadLine());
                                    }
                                }


                                /* Pour le spasfon */

                                if (type == 'S' && quantite_spasfon != 0)
                                {
                                    Console.WriteLine("Quelle quantité de spasfon voulez-vous vendre ?");
                                    quantite_spasfon_vente = int.Parse(Console.ReadLine());

                                    if (quantite_spasfon_vente > quantite_spasfon)
                                    {
                                        Console.WriteLine("Stock insuffisant");
                                    }

                                    else
                                    {
                                        quantite_spasfon -= quantite_spasfon_vente;

                                        Console.WriteLine("A combien voulez-vous vendre le spasfon ?");
                                        prix_spasfon = int.Parse(Console.ReadLine());
                                    }
                                }
                            }
                        }
                    }

                    else
                    {
                        Console.WriteLine("Le stock est vide, vous ne pouvez rien vendre");
                    }

                    Console.WriteLine("Vous avez vendu : " + quantite_doliprane_vente + " doliprane. Le prix unitaire est de " + prix_doliprane + " euros. Total : " + quantite_doliprane_vente * prix_doliprane);
                    Console.WriteLine("Vous avez vendu : " + quantite_ibuprofene_vente + " ibuprofene. Le prix unitaire est de " + prix_ibuprofene + " euros. Total : " + quantite_ibuprofene_vente * prix_ibuprofene);
                    Console.WriteLine("Vous avez vendu : " + quantite_efferalgan_vente + " efferalgan. Le prix unitaire est de " + prix_efferalgan + " euros. Total : " + quantite_efferalgan_vente * prix_efferalgan);
                    Console.WriteLine("Vous avez vendu : " + quantite_spasfon_vente + " spasfon. Le prix unitaire est de " + prix_spasfon + " euros. Total : " + quantite_spasfon_vente * prix_spasfon);
                    vente = true;
                }


                /* Visualiser le stock */

                else if (demande == "VS")
                {
                    Console.WriteLine("Quantité de doliprane : " + quantite_doliprane);
                    Console.WriteLine("Quantité d'ibuprofene : " + quantite_ibuprofene);
                    Console.WriteLine("Quantité d'efferalgan : " + quantite_efferalgan);
                    Console.WriteLine("Quantité de spasfon : " + quantite_spasfon);
                }

                else if (demande == "stop")
                {
                    continuer = false;
                }

                else
                {
                    Console.WriteLine("Cette demande n'est pas prise en compte");
                }
            }
        }
    }
}